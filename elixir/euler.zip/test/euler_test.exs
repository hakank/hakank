defmodule EulerTest do

  use ExUnit.Case
  @moduletag :capture_log
  
  import Euler
  import NumberTheory
  
  doctest Euler
  doctest NumberTheory  

  test "fib 10" do
    assert fib(10) == 55
  end

  test "prime?(100)" do
    assert prime?(100) == false
  end
  
end
