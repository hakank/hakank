defmodule Mix.Tasks.RunProgram do
  use Mix.Task

  # import Euler
  
  @shortdoc "Runs a specific program"
  def run(args) do
    if args === [] do
      Euler.run_all()
    else
      for a <- args do
        # If a is not a number string, I just let it crash...
        e = "Euler" <> a <> ".run_all()"
        Code.eval_string(e)
        # Euler.run_all(e)
        |> IO.inspect
        # IO.puts("")
      end
    end
  end
end
