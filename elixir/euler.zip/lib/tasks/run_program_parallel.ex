defmodule Mix.Tasks.RunProgramParallel do
  use Mix.Task

  # import Euler
  
  @shortdoc "Runs a specific program"
  def run(args) do
    if args === [] do
      Euler.run_all_parallel()
    else
      # for a <- args do
      #   # If it's not a number string, I just let it crash...
      #   e = "Euler" <> a <> ".run_all_parallel()"
      #   Code.eval_string(e)
      #   IO.puts("")
      # end
    end
  end
end
