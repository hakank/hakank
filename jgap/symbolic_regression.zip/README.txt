These files are for Symbolic Regression in JGAP.
For more info, see my web site http://www.hakank.org/jgap/

Hakan Kjellerstrand
hakank@bonetmail.com
http://www.hakank.org/

 
